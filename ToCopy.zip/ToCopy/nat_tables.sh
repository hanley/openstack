#!/bin/bash
###########################################
# program: nat_tables.sh #
# Author: Diarmuid O'Briain #
# Copyright ©2017 C²S Consulting #
# License: www.gnu.org/licenses/gpl.txt #
###########################################
# NAT masquerade rules for hypervisor, hosting OpenStack testbed #
# Select interface, typically 'wlp4s0' for WIFI and 'enp0s3' for wired Ethernet
INTERFACE=enp3s0 # Unhash for wired Ethernet interface
#INTERFACE=wlp4s0 # Unhash for wireless WIFI interface
# Select instance private network
NETWORK=virbr2 # For KVM/QEMU
#NETWORK=vboxnet1 # For VirtualBox
# Flush iptables
iptables -F
iptables -F -t nat
# Enable IP forwarding
echo
echo "echo \"1\" > /proc/sys/net/ipv4/ip_forward"
echo "1" > /proc/sys/net/ipv4/ip_forward
echo
# Load GNU/Linux kernel modules
modprobe ip_tables
modprobe ip_conntrack
# Add IPTABLES rules
iptables -t nat -A POSTROUTING -o $INTERFACE -j MASQUERADE
iptables -A FORWARD -i $INTERFACE -o $NETWORK -m state --state RELATED,ESTABLISHED -j ACCEPT
iptables -A FORWARD -i $NETWORK -o $INTERFACE -j ACCEPT
# Print iptables
iptables -t nat -v -L POSTROUTING
echo
iptables -v -L FORWARD
# END