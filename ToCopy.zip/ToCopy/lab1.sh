#!/usr/bin/env bash

set -o errexit -o nounset

TOP_DIR=$(cd $(cat "../TOP_DIR" 2>/dev/null||echo $(dirname "$0"))/.. && pwd)
#TOP_DIR=$(cd ./.. && pwd)
#TOP_DIR=/

source "paths"
source "functions.guest.sh"
#inside refer to osbash/config/credentials, osbash/lib/functions.sh, osbash/lib/functions-common-devstack

#ubuntu/apt_init.sh

REPO=cloud-archive:train
CONTROLLER_MGMT_IP="10.0.0.4"
DB_IP="10.0.0.4"


echo "Installing packages needed for add-apt-repository."
sudo apt -y install software-properties-common

echo "Adding cloud repo: $REPO"
sudo add-apt-repository -y "$REPO"

# Disable automatic updates (they compete with our scripts for the dpkg lock)
sudo systemctl disable apt-daily.service
sudo systemctl disable apt-daily.timer


# ---------------------------------------------------------------------------
# Not in install-guide:
# Install mariadb-server from upstream repo (mariadb 10.1 shipping with
# bionic breaks the neutron database upgrade process in OpenStack Train)
# ---------------------------------------------------------------------------

# Add mariadb repo
cat << EOF | sudo tee /etc/apt/sources.list.d/mariadb.list
# bionic mariadb 10.1 breaks neutron DB upgrade process in OpenStack Train
deb http://downloads.mariadb.com/MariaDB/mariadb-10.3/repo/ubuntu bionic main
EOF

# Import key required for mariadb
sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys F1656F24C74CD1D8

# Update apt database for mariadb repo
sudo apt update \
    -o Dir::Etc::sourcelist="sources.list.d/mariadb.list" \
    -o Dir::Etc::sourceparts="-" -o APT::Get::List-Cleanup="0"

# Pre-configure database root password in /var/cache/debconf/passwords.dat
# (the upstream mariadb-server has socket_auth disabled)
source "credentials"
echo "mysql-server mysql-server/root_password password $DATABASE_PASSWORD" | sudo debconf-set-selections
echo "mysql-server mysql-server/root_password_again password $DATABASE_PASSWORD" | sudo debconf-set-selections

#ubuntu/apt-upgrade.sh

sudo apt -y dist-upgrade

# Clean apt cache
sudo apt -y autoremove
sudo apt -y clean

echo "Installing OpenStack client."
sudo apt install -y python3-openstackclient

# Starting with bionic, the Ubuntu LTS switched to a new set of network
# management. We install and use the legacy tools for the time being.
sudo apt install -y ifupdown

echo "Installing curl, tree (they are small and useful)."
sudo apt install -y curl tree

#osbash/scripts/osbash/init_xxx_node.sh => skip

#ubuntu/etc_hosts.sh

# The install-guide wants to use the hostname as the name of the interface
# in the mgmt network. We cannot allow 127.0.0.1 to share the name.
HOST_NAME=$(hostname)-lo
HOST_FILE=/etc/hosts

if ! grep -q "^[^#].*$HOST_NAME" $HOST_FILE; then
    # No active entry for our hostname
    HOST_IP=127.0.1.1
    if grep -q "^$HOST_IP" $HOST_FILE; then
        # Fix the entry for the IP address we want to use
        sudo sed -i "s/^$HOST_IP.*/$HOST_IP $HOST_NAME/" $HOST_FILE
    else
        echo "$HOST_IP $HOST_NAME" | sudo tee -a $HOST_FILE
    fi
fi

# Add entries for the OpenStack training-labs cluster
#osbash/config/hosts.multi
cat "hosts.multi" | sudo tee -a /etc/hosts

#osbash/scripts/osbash/copy_openrc.sh => must have admin-openstackrc.sh & demo-openstackrc.sh


# Replace variables with constants and keep only lines starting with export

cat "admin-openstackrc.sh" | sed -ne "
    s/\$ADMIN_PROJECT_NAME/$ADMIN_PROJECT_NAME/
    s/\$ADMIN_USER_NAME/$ADMIN_USER_NAME/
    s/\$ADMIN_PASS/$ADMIN_PASS/
    s/controller/$CONTROLLER_MGMT_IP/
    /^export/p
    " > "$HOME/admin-openrc.sh"

cat "demo-openstackrc.sh" | sed -ne "
    s/\$DEMO_PROJECT_NAME/$DEMO_PROJECT_NAME/
    s/\$DEMO_USER_NAME/$DEMO_USER_NAME/
    s/\$DEMO_PASS/$DEMO_PASS/
    s/controller/$CONTROLLER_MGMT_IP/
    /^export/p
    " > "$HOME/demo-openrc.sh"

#environment
#apt_install_mysql.sh

#-------------------------------------------------------------------------------
# Controller setup
#-------------------------------------------------------------------------------

echo "Will bind MySQL server to $DB_IP."

#------------------------------------------------------------------------------
# Install and configure the database server
# https://docs.openstack.org/install-guide/environment-sql-database-ubuntu.html
#------------------------------------------------------------------------------

echo "Sourced MySQL password from credentials: $DATABASE_PASSWORD"

#sudo debconf-set-selections  <<< 'mysql-server mysql-server/root_password password '$DATABASE_PASSWORD''
#sudo debconf-set-selections <<< 'mysql-server mysql-server/root_password_again password '$DATABASE_PASSWORD''

echo "Installing MySQL (MariaDB)."
sudo apt install -y mariadb-server python-mysqldb

# Not in the install-guide
echo "Sanity check: check if password login works for root."
sudo mysql -u root -p"$DATABASE_PASSWORD" -e quit

# Not in install-guide
# To drop socket auth for root user and use root password:
# sudo mysql -u "root" -e "use mysql; update user set plugin='' where user='root'; update user set password=PASSWORD('$DATABASE_PASSWORD') where user='root'; flush privileges;"

conf=/etc/mysql/mariadb.conf.d/99-openstack.cnf

echo "Creating $conf."
echo '[mysqld]' | sudo tee $conf

echo "Configuring MySQL to accept requests from management network ($DB_IP)."


iniset_sudo $conf mysqld bind-address "$DB_IP"

iniset_sudo $conf mysqld default-storage-engine innodb
iniset_sudo $conf mysqld innodb_file_per_table on
iniset_sudo $conf mysqld max_connections 4096
iniset_sudo $conf mysqld collation-server utf8_general_ci
iniset_sudo $conf mysqld character-set-server utf8

echo "Restarting MySQL service."
# Close the file descriptor or the script will hang due to open ssh connection
sudo service mysql restart 2>/dev/null

# Difference to install-guide: not running mysql_secure_installation

#ubuntu/install_rabbitmq.sh

#-------------------------------------------------------------------------------
# Install the message broker service (RabbitMQ).
# https://docs.openstack.org/install-guide/environment-messaging-ubuntu.html
#-------------------------------------------------------------------------------

echo "Installing RabbitMQ."
sudo apt install -y rabbitmq-server

echo -n "Waiting for RabbitMQ to start."
until sudo rabbitmqctl status >/dev/null; do
    sleep 1
    echo -n .
done
echo

echo ---------------------------------------------------------------
echo "sudo rabbitmqctl status"
sudo rabbitmqctl status
echo - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
echo "sudo rabbitmqctl report"
sudo rabbitmqctl report
echo ---------------------------------------------------------------

echo "Adding openstack user to messaging service."
sudo rabbitmqctl add_user openstack "$RABBIT_PASS"

echo "Permitting configuration, write and read access for the openstack user."
sudo rabbitmqctl set_permissions openstack ".*" ".*" ".*"

#ubuntu/install_memcached.sh

#------------------------------------------------------------------------------
# Memcached
# https://docs.openstack.org/install-guide/environment-memcached-ubuntu.html
#------------------------------------------------------------------------------

echo "Installing memcache packages."
sudo apt install -y memcached python-memcache

MGMT_IP=0.0.0.0
echo "Binding memcached server to $MGMT_IP."

conf=/etc/memcached.conf
sudo sed -i "s/^-l 127.0.0.1/-l $MGMT_IP/" $conf

echo "Restarting memcache service."
sudo service memcached restart
