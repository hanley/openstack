#!/usr/bin/env bash

set -o errexit -o nounset

TOP_DIR=$(cd $(cat "../TOP_DIR" 2>/dev/null||echo $(dirname "$0"))/.. && pwd)

source "paths"
source "functions.guest.sh"

function apt_download {
    echo "apt_download: $*"
    sudo apt install -y --download-only "$@"
}
REPO=cloud-archive:train


echo "Installing packages needed for add-apt-repository."
sudo apt -y install software-properties-common

echo "Adding cloud repo: $REPO"
sudo add-apt-repository -y "$REPO"

# Disable automatic updates (they compete with our scripts for the dpkg lock)
sudo systemctl disable apt-daily.service
sudo systemctl disable apt-daily.timer

# Add mariadb repo
cat << EOF | sudo tee /etc/apt/sources.list.d/mariadb.list
# bionic mariadb 10.1 breaks neutron DB upgrade process in OpenStack Train
deb http://downloads.mariadb.com/MariaDB/mariadb-10.3/repo/ubuntu bionic main
EOF

# Import key required for mariadb
sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys F1656F24C74CD1D8

# Update apt database for mariadb repo
sudo apt update \
    -o Dir::Etc::sourcelist="sources.list.d/mariadb.list" \
    -o Dir::Etc::sourceparts="-" -o APT::Get::List-Cleanup="0"

sudo apt -y dist-upgrade

# Clean apt cache
sudo apt -y autoremove
sudo apt -y clean

echo "Installing OpenStack client."
sudo apt install -y python3-openstackclient

# Download packages for all nodes

# MySQL, RabbitMQ
apt_download mariadb-server python-mysqldb rabbitmq-server

# NoSQL database (MongoDB)
#apt_download mongodb-server mongodb-clients python-pymongo

# Other dependencies
apt_download python-argparse python-dev python-pip

# Keystone
apt_download keystone python3-openstackclient apache2 \
    memcached python-memcache

# Glance
apt_download glance python3-glanceclient

# Nova Controller
apt_download nova-api nova-conductor nova-novncproxy nova-scheduler

# Placement Controller
apt_download placement-api

# Neutron Controller
apt_download neutron-server neutron-plugin-ml2 \
    neutron-linuxbridge-agent neutron-dhcp-agent \
    neutron-metadata-agent neutron-l3-agent python3-neutronclient conntrack

# Cinder Controller
#apt_download cinder-api cinder-scheduler python3-cinderclient

# Horizon
apt_download openstack-dashboard

# Cinder Volumes
#apt_download lvm2 cinder-volume thin-provisioning-tools

# Nova Compute
#apt_download nova-compute nova-compute-qemu qemu sysfsutils

# Neutron Compute
#apt_download neutron-linuxbridge-agent

# Heat
#apt_download heat-api heat-api-cfn heat-engine python3-heatclient

# Swift Controller
#apt_download swift swift-proxy python3-swiftclient \
 #   python3-keystoneclient python3-keystonemiddleware \
  #  memcached

# Swift Storage
#apt_download xfsprogs rsync \
 #   swift swift-account swift-container swift-object

# PXE server
#apt_download bind9 isc-dhcp-server apache2 tftpd-hpa inetutils-inetd vlan \
 #   iptables-persistent
